'use strict';
const inp = document.querySelector('.inp');
const show = document.querySelector('.show');
let participant = 0;
document.querySelector('.btn').addEventListener('click', function () {
  participant = inp.value;
  let x = Math.round(Math.random() * participant);
  show.textContent = `شماره قرعه برابر است با : ${x}`;
});
